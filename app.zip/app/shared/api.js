Api.$inject = [
    'endpoint'
];

function Api(endpoint) {
   
    return {
        
    };
}

module.exports = Api;
