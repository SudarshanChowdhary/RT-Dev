ErrorController.$inject = ['$state', '$scope'];

function ErrorController($state, $scope) {
    var vmerror = this;
    // Variable Definitions
    
    
}
module.exports = ErrorController;