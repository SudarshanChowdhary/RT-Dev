module.exports = {
    versioning: false,
    debug: true,
};