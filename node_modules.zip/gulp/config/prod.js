module.exports = {
    versioning: true,
    debug: false,
    optimize: true
};