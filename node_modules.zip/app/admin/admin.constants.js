module.exports = {
    MODULES: [{
        'id': 1,
        'name': 'Repository'
    }, {
        'id': 2,
        'name': 'Tickets'
    }, {
        'id': 3,
        'name': 'Defects'
    },{
        'id': 4,
        'name': 'Team'
    },
        {
        'id': 5,
        'name': 'Reports'
    }
    ],
    LEVEL: [{
        'name': 0
    }, {
        'name': 1
    }, {
        'name': 2
    }, {
        'name': 3
    },{
       'name': 4 
    }]
};