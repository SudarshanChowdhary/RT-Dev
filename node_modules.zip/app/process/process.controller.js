ProcessController.$inject = ['$state', '$scope', '$log'];

function ProcessController($state, $scope, $log) {
    var vmpro = this;
    // Variable Definitions
    // Function Definitions
    vmpro.init = init;
    init();
    /**
     * init
     * Intializing On Load Services for Set Up Client Page
     */
    function init() {}
}
module.exports = ProcessController;